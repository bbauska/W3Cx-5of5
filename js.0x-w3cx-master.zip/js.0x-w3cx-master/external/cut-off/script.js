function init(){
	console.log("Init.");
}

function clickSo(){
	console.log("clickSo 1");
	var string = document.querySelector("#divSo");
	console.log(string);
	console.log("clickSo 2");

}