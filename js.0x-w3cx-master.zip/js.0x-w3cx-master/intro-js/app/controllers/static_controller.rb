class StaticController < ApplicationController
  def city
  end

  def home_page
  end
end
